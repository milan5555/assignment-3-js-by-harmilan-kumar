document.addEventListener("DOMContentLoaded", function() {
    const funButton = document.getElementById('fun-button');
    const originalText = document.querySelector('h1').textContent;
    const funnyText = "Welcome to the Fun-tastic Page!";
    const colors = ['#ffcccb', '#ffd700', '#87ceeb', '#98fb98', '#ff69b4'];

    funButton.addEventListener('click', function() {
        document.body.style.backgroundColor = getRandomColor();
        document.querySelector('h1').textContent = funnyText;
    });

    function getRandomColor() {
        return colors[Math.floor(Math.random() * colors.length)];
    }
});
